using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod2_Lab
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, reminder;
            for(i=1;i<=8;i++)
            {
                for(j=1;j<=8;j++)
                {
                    if(i%2==0)

                }

            }
        }
    }
}
