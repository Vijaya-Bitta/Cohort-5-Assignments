using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod3_Assignment
{
    class Program
    {
        static void Main(string[] args)
        { 
            
            GetStudentInformation();
            
            GetStudentBirthday();

            try
            {
                ValidateBirthday();
            }
           
            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (NotImplementedException notImp)
            {
                Console.WriteLine(notImp.Message);
            }

            GetTeacherInformation();

            GetCourseInformation();

            GetUProgarmInformation();

            GetDegreeInformation();

            Console.WriteLine("***** STUDENT INFORMATION ******");
            PrintStudentInformation();
            PrintStudentBirthday();

            Console.WriteLine("\n******** TEACHER INFORMATION*****");
            PrintTeacherInformation();

            Console.WriteLine("\n******* UPROGRAM ********");
            PrintUprogarmInformation();

            Console.WriteLine("\n******* DEGREE INFORMATION *******");
            PrintDegreeInformation();

            Console.WriteLine("\n****** COURSE INFORMATION ********");
            PrintCourseInformation();

                   
            Console.ReadLine();
            
        }
        //Student Information
        static string sFirstName, sLastname;
       
        static void GetStudentInformation()
         {
            Console.WriteLine("Enter Student First Name: ");
            sFirstName =Console.ReadLine();
            Console.WriteLine("Enter Student Last Name: ");
            sLastname=Console.ReadLine();
                       
            Console.WriteLine();
                
         }

        static DateTime sBirthday;
        static void GetStudentBirthday()
        {
            try
            {
                
                Console.WriteLine("Enter student birthday");
                sBirthday = DateTime.Parse(Console.ReadLine());
            }
            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
           
        }
        static void ValidateBirthday()
        {
           
            throw new NotImplementedException();
        }

        static void PrintStudentBirthday()
        {
            Console.WriteLine("Student Birthday is {0}",sBirthday);
        }

        static void PrintStudentInformation()
         {
             Console.WriteLine("Stude Name {0} {1}", sFirstName,sLastname);
         }

        //Teacher Information
        static string tFirstname, tLastName;
        static DateTime tBirthday;
        static void GetTeacherInformation()
         {
            Console.WriteLine("Enter Teacher First Name: ");
            tFirstname=Console.ReadLine();
            Console.WriteLine("Enter Teacher Last Name: ");
            tLastName=Console.ReadLine();
            Console.WriteLine("Enter Teacher Date of Birth");
            tBirthday = DateTime.Parse(Console.ReadLine());  
             
            Console.WriteLine();
         }

        static void PrintTeacherInformation()
         {
             Console.WriteLine("{0} {1} was born on: {2}", tFirstname,tLastName,tBirthday);
         }

        //Uprogram information

        static string programName;
        static string deptName;
        static string degree;
        static void GetUProgarmInformation()
            {
            Console.WriteLine("Enter Program Name:");
            programName=Console.ReadLine();
            Console.WriteLine("Enter Department Name:");
            deptName=Console.ReadLine();
            Console.WriteLine("Enter Degrees");
            degree=Console.ReadLine();
            
            }
        static void PrintUprogarmInformation()
            {
            Console.WriteLine($"Uprogram name {programName}");
            Console.WriteLine($"Departmet name {deptName}");
            Console.WriteLine($"Degrees {degree}");
            }

        //Degree Inforamtion
        static string degreeName;
        static int creditsReq;
        static void GetDegreeInformation()
            {
            Console.WriteLine("Enter Degree Name");
            degreeName= Console.ReadLine();
            Console.WriteLine("Enter the Credits Required");
            creditsReq=Int32.Parse(Console.ReadLine());
            
            }

        static void PrintDegreeInformation()
            {
            Console.WriteLine($"Degree Name is {degreeName} and {creditsReq} Credits Required");
             }

        //Course Information 
        static string courseName, teacherName;
        static int credits, duration;

        static void GetCourseInformation()
            {
            Console.WriteLine("Enter Course name");
            courseName=Console.ReadLine();
             Console.WriteLine("Enter Credits");
            credits=Int32.Parse(Console.ReadLine());
             Console.WriteLine("Enter Duration in weeks");
            duration=Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter Teacher Name");
            teacherName=Console.ReadLine();
            
            }

        static void PrintCourseInformation()
            {
            Console.WriteLine("Course Name is {0}",courseName);
            Console.WriteLine($"{credits} Credits Required");
            Console.WriteLine($"{duration} Weeks Duration");
            Console.WriteLine($"Teacher Name is {teacherName}");
            }

    }
}
