using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod3_Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
             int result = Sum(40, 50);
            Console.WriteLine($"Sum of 40 + 50 is {result}");

            int result2 = Sum(10, 10, 10);
            Console.WriteLine($"Sum of 10 + 10 + 10 is {result2}");

            double result3 = Sum(20.45, 50.10);
            Console.WriteLine($"Sum of 20.45 + 50.10 is {result3}");
        }

        // Method declaring using void 
        //public static void Sum(int first, int second)
        //{
        //    int result = first + second;
        //    Console.WriteLine($" The sum of {first}+{second} is {result}");
        //}

        // Method declaring with return type
        public static int Sum(int first,int second)
        {
            return first + second;
        }


        //Method Overloading

        public static int Sum(int first, int second, int third)
        {
            return first + second + third;
        }

        public static double Sum(double first, double second)
        {
            return first + second;
        }
    }
}
