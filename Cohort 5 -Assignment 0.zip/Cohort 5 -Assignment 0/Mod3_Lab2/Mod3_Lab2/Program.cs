using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Mod3_Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Enter a value:");
            a = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter b value:");
            b = Int32.Parse(Console.ReadLine());
            Divide(a,b);

        }

        //Devision Method with exception handling

        public static void Divide(int a, int b)
        {
            try
            {
                int result = a / b;
                Console.WriteLine($"DEvided {a} by {b} is {result}");

            }
            catch(System.DivideByZeroException e)
            {
                Console.WriteLine("Cannot divided by zero. Please provide non zero number for division");
            }
            

        }
    }
    
}

    

