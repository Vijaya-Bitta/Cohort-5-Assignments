using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod1_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Student Information

            string FirstName = "John";
            string LastName = "Scott";
            string AddressLine1 = "15th st, #2001";
            string AddressLine2 = "18th Ave,#E12";
            string City ="Bellevue";
            string StateOrProvince="WA";
            int ZipCode =98007;
            string Country ="United States";

            Console.WriteLine("*****Student Information*****");
            Console.WriteLine("First Name " + FirstName);
            Console.WriteLine("Last Name " + LastName);
            Console.WriteLine("Address Line1 " + AddressLine1);
            Console.WriteLine("Address Line 2 " + AddressLine2);
            Console.WriteLine("City" + City);
            Console.WriteLine("State / Province" + StateOrProvince);
            Console.WriteLine("Zip Code " + ZipCode);
            Console.WriteLine("Country " + Country);

          

            //Teacher Information;
            string TFirstName = "Marves";
            string TLastName ="Hedge";
            string TAddressLine1 = "17th PL,#300";
            string TAddressLine2 = "19th PL, #A1";
            string TCity ="Redmond";
            string TStateOrProvince = "WA";
            int TZipCode = 98052;
            string TCountry = "United States";

            Console.WriteLine("*****Teacher Information*****");
            Console.WriteLine("First Name " + TFirstName);
            Console.WriteLine("Last Name " + TLastName);
            Console.WriteLine("Address Line1 " + TAddressLine1);
            Console.WriteLine("Address Line 2 " + TAddressLine2);
            Console.WriteLine("City" + TCity);
            Console.WriteLine("State / Province" + TStateOrProvince);
            Console.WriteLine("Zip Code " + TZipCode);
            Console.WriteLine("Country " + TCountry);

            //UProgram Information

            string ProgramName = "Boot Camp";
            string DeptHead ="Kal";

            Console.WriteLine("*** UProgram Information");
            Console.WriteLine("Program Name " + ProgramName);
            Console.WriteLine("Department Head " + DeptHead);

            //Degree Information

            string DegreeName="Masters";
            int CreditReq =35;

            Console.WriteLine("*** Degree Informaion****");
            Console.WriteLine("Degree Name" + DegreeName);
            Console.WriteLine("Credit Requires " + CreditReq);


            //Course Information
            string CourseName ="C#";
            int credits = 35;
            int DurationInWeeks =16;
            string Teacher ="Kal";

            Console.WriteLine("*** Course Information ****");
            Console.WriteLine("CousrName" + CourseName);
            Console.WriteLine("Credits " + credits);
            Console.WriteLine("Duration IN Weeks " + DurationInWeeks);
            Console.WriteLine("Teacher " + Teacher);
        }
    }
}
